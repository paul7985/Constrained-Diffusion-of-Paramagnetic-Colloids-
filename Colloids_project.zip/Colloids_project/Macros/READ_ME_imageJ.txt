On utilise ImageJ pour convertir les données brutes (les vidéos) en coordonnées x,y,t dans un fichier .csv, qu'on peut ensuite analyser grâce aux codes MATLAB.
J'ai écrit la macro (macro_movie_Paul.ijm) moi-même car le traitement peut-être long et j'ai préféré ajouter quelques options comme : 
la possibilité de faire plusieurs fichiers à la suite, sous toucher l'ordinateur (idéal pour faire tourner la nuit)
Choisir la destination d'enregistrement


Pour que ça fonctionne il faut cliquer sur le raccourci sur le bureau :'ImageJ-win64.exe - Raccourci', c'est la version qui possède tous les plugins de traitement.

Il faut suivre les étapes suivantes : Plugins -> Macros -> Run -> cliquer sur le fichier macro_movie.

On choisit (ou crée) le dossier dans lequel sera enregistré le fichier .csv. Le nom du fichier généré par la macro dépend du nom initial donné à la mesure via micro-manager.

Spécifier le nombre de fichiers à traiter. Si tu veux enregistrer les différents fichiers dans différents dossiers, il faudra modifier la macro.
J'ai toujours enregistré les fichiers d'une même série de mesures dans le même dossier, je n'ai donc pas ajouté cette possibilité.

Sélectionner le dossier contenant les images. Le dernier dossier sélectionné devrait être un dossier 'Pos0', c'est automatiquement généré par le micro-manager. 
A ce moment, aucune image n'apparait, mais elles existent bien. Il suffit de cliquer sur select.

La macro devrait fonctionner.


Quelques astuces : 
Pour modifier les paramètres d'analyse de la macro et vérifier à quoi ressemble le filtrage qu'on applique à l'image :

'macro_test.ijm' est une version réduite de 'macro_movie_paul.ijm'. elle contient le filtre sans les processus d'enregistrement, de sélection de dossier et de traitement 'vidéo'.
On l'utilise uniquement pour vérifier la pertinence du filtrage sur une image de l'échantillon, voici le protocole à suivre :

File -> Open -> Sélectionner la 'macro_test.ijm'. On peut désormais modifier les paramètres de filtrage, notamment : la taille des billes à filtrer ('area') 
et la méthode de filtrage ('Phansalkar'), j'ai utilisé Phansalkar pour toutes mes mesures, je n'ai pas eu besoin d'en utiliser une autre.

Pour tester les paramètres de filtrage sur une image, il faut une image. 
File -> Open -> Sélectionner une image aléatoire dans la série de mesures d'intérêt.

Si, dans la fenêtre Java qui contient la 'macro_test', on appuie sur Run, la macro devrait s'appliquer automatiquement à l'image ouverte.
Pour éviter de répéter l'ouverture d'image en boucle, je recommande d'ouvrir l'image une première fois puis de la dupliquer via 'Ctrl+D'. Ca permet de répéter les tests 
en ayant une image rapidement. 

Une fois les paramètres idéaux spécifiés dans la macro_test, il suffit de modifier les lignes dans la macro_movie_paul. Il faut l'ouvrir de la même manière, modifier, enregistrer.



