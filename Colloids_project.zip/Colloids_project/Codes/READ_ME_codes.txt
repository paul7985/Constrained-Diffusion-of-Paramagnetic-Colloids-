Contexte général

Ce document présente et décrit les différents scripts MATLAB développés pour l’analyse du
mouvement de colloïdes paramagnétiques soumis à un champ magnétique vertical. Cette analyse
a été menée dans le cadre d’un stage de recherche au LCP-A2MC et repose sur le traitement de
trajectoires de particules extraites par microscopie.
L’objectif principal est de calculer et d’interpréter le déplacement quadratique moyen (MSD) dans
des conditions variées, en tenant compte de la dérive éventuelle du système. Plusieurs approches ont
été explorées : traitement global ou local, avec ou sans correction, analyses individuelles ou collectives,
afin de mettre en évidence un éventuel effet de caging (confinement des particules par leurs voisines).
Chaque script est replacé dans son contexte, avec une description claire de son rôle, de ses
entrées/sorties et des cas où il est particulièrement utile.

Organisation du dossier par catégories
Les scripts sont organisés selon leur fonction dominante :
1. Calculs standards du MSD
2. Correction de la dérive (globale ou locale, notamment via moyenne mobile)
3. Analyses restreintes (zones calmes, particules individuelles)
4. Études paramétriques (dépendance au rayon de correction, au temps, etc.)
5. Visualisation et fonctions utilitaires

1 Calculs standards du MSD
— calcul_MSD.m :
Charge plusieurs fichiers CSV contenant les trajectoires de particules. Le script applique
une conversion temps/position, puis calcule le MSD moyen. Pratique pour une première
visualisation des dynamiques sans correction de dérive.
— calcul_msd_r_david_OK.m :
Version plus complète du précédent. Applique une conversion pixel → μm, propose une
sélection de fichiers via boîte de dialogue, et calcule le MSD pour chaque fichier avant de faire
une moyenne. Fiable pour produire des courbes finales avec unités physiques.
— msd_individuel.m :
Analyse le MSD pour chaque particule individuellement, sans moyenne. Idéal pour visualiser
les disparités entre particules et détecter des trajectoires aberrantes. Fournit aussi un
aperçu utile de la dispersion des dynamiques.
— MSD_1_intervalle_STD.m :
Calcule le MSD à un instant donné (lag unique) pour chaque fichier. Cela permet une comparaison
rapide de plusieurs expériences en se concentrant sur une seule échelle temporelle (par exemple,
τ = 10s).

2 Correction de dérive (méthodes locales ou globales)
— MSD_moyenne_mobile_traj.m, test_MSD_moyenne_mobile.m, test_MSD_traj_moyenne_mobile.m :
Ces scripts appliquent une correction locale de la dérive à l’aide d’une moyenne mobile :
la vitesse moyenne des particules voisines dans un rayon donné est estimée puis soustraite à la
trajectoire d’une particule. On corrige ainsi les effets de convection ou de flux global tout en
préservant la dynamique locale. Ces scripts sont essentiels pour révéler le mouvement diffusif
propre à chaque particule.
— MSD_rayon_MA.m :
Permet d’explorer l’influence du rayon de voisinage utilisé pour la moyenne mobile sur le
résultat du MSD. Fournit un graphique comparant les différentes valeurs de rayon, et aide à
choisir un compromis entre suppression de la dérive et préservation du signal.

3 Analyses restreintes (zones calmes, particules seules)
— msd_zone_restreinte.m, msd_zone_restreinte_et_traj.m :
Filtrent les trajectoires pour ne garder que celles situées dans une zone spatiale donnée
(définie en X et Y). Cela permet d’isoler des zones où la dérive est faible ou où le système
semble plus homogène. La version _et_traj inclut aussi une visualisation des trajectoires
retenues.
— msd_solo_comprehension.m :
Étudie le comportement du MSD pour une seule particule, choisie manuellement. Utile
pour comprendre la nature des erreurs ou tester si un comportement particulier est généralisable.
A explorer pour du diagnostic local.

4 Études paramétriques
— msd_fonction_r.m, msd_fonction_r_2.m, msd_fonction_r_max_test.m :
Testent différentes valeurs du rayon de voisinage pour la correction par moyenne mobile
et observent l’évolution du MSD. Ces scripts sont ceux utilisés pour produire des figures de
type “MSD vs rayon” (voir par exemple la figure 11 du rapport). Ils permettent de quantifier
l’effet de la correction locale.
— msd_solo_fonction_r.m, msd_solo_fonction_r_2.m :
Même objectif que ci-dessus, mais sur une particule unique. Permet d’évaluer si la dépendance
au rayon est uniforme ou bien variable selon les trajectoires.

5 Comparaison de manipulations
— code_comparaison_msd.m, code_comparaison_msd_sans_drift.m, code_comparaison_msd_1intervalle_sans_code_comparaison_msd_sans_drift_v2_test.m :
Ces scripts comparent plusieurs expériences (ou plusieurs zones d’une même expérience)
avec ou sans correction de dérive. Certains utilisent une moyenne sur plusieurs fichiers,
d’autres un seul fichier à la fois. Ils sont utiles pour tester la reproductibilité des mesures
ou évaluer l’effet de paramètres expérimentaux (champ magnétique, concentration, taille des
billes, etc.).

6 Visualisation et outils pratiques
— Plot_superposition_image.m :
Superpose les trajectoires de particules à une image d’arrière-plan (issue d’ImageJ par
exemple). Permet de vérifier que les trajectoires calculées correspondent bien aux positions
réelles sur l’image brute.
— plot_trajectoires.m :
Affiche toutes les trajectoires détectées sur un même graphe. Utile pour repérer visuellement
des zones à dérive forte ou des artefacts.
— Track_Particles.m, track.m :
Fonctions de suivi de particules. Génèrent les trajectoires en connectant les positions
détectées image par image. Utilisent une distance maximale de déplacement entre deux frames
(paramètre maxdisp).
